/*
 * Copyright (c) Huawei Technologies Co., Ltd. 2023-2023. All rights reserved.
 */

#ifndef FFTM_H
#define FFTM_H

#include <stdint.h>
#include <stddef.h>

#define MAX_STAGE_COUNT 32
#ifdef __cplusplus
extern "C" {
#endif
typedef enum {
    FFT_R2HC = 0,
    FFT_HC2R = 1,
    FFT_DHT = 2,
    FFT_REDFT00 = 3,
    FFT_REDFT01 = 4,
    FFT_REDFT10 = 5,
    FFT_REDFT11 = 6,
    FFT_RODFT00 = 7,
    FFT_RODFT01 = 8,
    FFT_RODFT10 = 9,
    FFT_RODFT11 = 10
} FFTR2RKind;

typedef struct {
    double real;
    double imag;
} FFTComplex;

typedef struct {
    double *bluesteinFactor;
    double *preComputedH;
    int lenPadded;
} BluesteinInfo;

typedef struct StFFTPlan1D {
    int n;
    int nStage;
    int sign;
    int flag;
    int iStride;
    int oStride;
    int unused1;
    int unused2;
    BluesteinInfo *bluesteinInfo;
    struct StFFTPlan1D *subPlan; // 引入sub-plan处理需要进行其余长度FFT的情况
    void *twiddle;
    void *splitFactor; // store as factor in R2C compute
    void *buffer0;
    void *buffer1;
    void *inPtr;
    void *outPtr;
    int radixList[MAX_STAGE_COUNT];
    int dftLenList[MAX_STAGE_COUNT];
    int sectionNum[MAX_STAGE_COUNT];
    int butterflyNum[MAX_STAGE_COUNT];
} FFTPlan1D;

typedef struct {
    void *tileBuffer;
    int nX;
    int tileN;
    int tileI;
} FFTPlan2DTileInfo;

typedef struct {
    // use 1-D plan directly, make sure that 1-D kernel can be partly reuse
    FFTPlan1D planX;
    FFTPlan1D planY;
    FFTPlan2DTileInfo tileInfo;
    void *bufferXY;
} FFTPlan2D;

typedef union {
    FFTPlan1D info1d;
    FFTPlan2D info2d;
} FFTPlanInfo;

typedef void* FftmFallbackPlan;

typedef struct {
    int ndims;
    int howmany;
    int iDistance;
    int oDistance;
    int sign;
    int flags;
    int fftType; // C2C/R2C/C2R
    int *iNEmbed;
    int *oNEmbed;
    int *n;
    void *in;
    void *out;
    FFTPlanInfo info;
    FftmFallbackPlan fallbackPlan;
} FFTPlan;

typedef FFTPlan* FftmPlan;

typedef struct {
    int n;
    int is;
    int os;
} FFTIodim;

typedef struct {
    ptrdiff_t n;
    ptrdiff_t is;
    ptrdiff_t os;
} FFTIodim64;

// C2C
FftmPlan FftPlanDft(int rank, const int *n, void *in, void *out, int sign, unsigned flags);
FftmPlan FftPlanDft1D(int n, void *in, void *out, int sign, unsigned flags);
FftmPlan FftPlanDft2D(int n0, int n1, void *in, void *out, int sign, unsigned flags);
FftmPlan FftPlanDft3D(int n0, int n1, int n2, void *in, void *out, int sign, unsigned flags);
FftmPlan FftPlanManyDft(int rank, const int *n, int howmany, void *in, const int *inembed,
    int istride, int idist,
    void *out, const int *onembed, int ostride, int odist, int sign, unsigned flags);
// R2C
FftmPlan FftPlanDftR2C(int rank, const int *n, double *in, void *out, unsigned flags);
FftmPlan FftPlanDftR2C1D(int n, double *in, void *out, unsigned flags);
FftmPlan FftPlanDftR2C2D(int n0, int n1, double *in, void *out, unsigned flags);
FftmPlan FftPlanManyDftR2C(int rank, const int *n, int howmany, double *in, const int *inembed,
    int istride, int idist,
    void *out, const int *onembed, int ostride, int odist, unsigned flags);
// C2R
FftmPlan FftPlanDftC2R(int rank, const int *n, void *in, double *out, unsigned flags);
FftmPlan FftPlanDftC2R1D(int n, void *in, double *out, unsigned flags);
FftmPlan FftPlanDftC2R2D(int n0, int n1, void *in, double *out, unsigned flags);
FftmPlan FftPlanManyDftC2R(int rank, const int *n, int howmany, void *in, const int *inembed,
    int istride, int idist,
    double *out, const int *onembed, int ostride, int odist, unsigned flags);
// execute
int FftExecute(FftmPlan plan);
int FftExecuteDft(FftmPlan plan, void *in, void *out);
int FftExecuteDftC2R(FftmPlan plan, void *in, double *out);
int FftExecuteDftR2C(FftmPlan plan, double *in, void *out);

// plan destroy
int FftDestroy(FftmPlan plan);
// memory
void *FftAlignPtr(void *ptr, const uint64_t n);
void *FftAlignedAlloc(const uint64_t size);
void FftAlignedFree(void *ptr);
// version
const char *FftGetVersion(void);

// wrap-function-execute
void FftExecuteR2R(const FftmPlan p, double *in, double *out);
void FftExecuteSplitDft(const FftmPlan p, double *ri, double *ii, double *ro, double *io);
void FftExecuteSplitDftR2C(const FftmPlan p, double *in, double *ro, double *io);
void FftExecuteSplitDftC2R(const FftmPlan p, double *ri, double *ii, double *out);

// C2C wrapper-plan interface
FftmPlan FftPlanDft3D(int n0, int n1, int n2, void *in, void *out, int sign, unsigned flags);
FftmPlan FftPlanGuruDft(int rank, const void *dims, int howmanyRank, const void *howmanyDims, void *in,
    void *out, int sign, unsigned flags);
FftmPlan FftPlanGuruSplitDft(int rank, const void *dims, int howmanyRank, const void *howmanyDims, double *ri,
    double *ii, double *ro, double *io, unsigned flags);
FftmPlan FftPlanGuru64Dft(int rank, const FFTIodim64 *dims, int howmanyRank, const FFTIodim64 *howmanyDims,
    void *in, void *out, int sign, unsigned flags);
FftmPlan FftPlanGuru64SplitDft(int rank, const FFTIodim64 *dims, int howmanyRank, const FFTIodim64 *howmanyDims,
    double *ri, double *ii, double *ro, double *io, unsigned flags);
// R2C wrapper-plan interface
FftmPlan FftPlanDftR2C3D(int n0, int n1, int n2, double *in, void *out, unsigned flags);
FftmPlan FftPlanGuruDftR2C(int rank, const void *dims, int howmanyRank, const void *howmanyDims, double *in,
    void *out, unsigned flags);
FftmPlan FftPlanGuruSplitDftR2C(int rank, const void *dims, int howmanyRank, const void *howmanyDims,
    double *in, double *ro, double *io, unsigned flags);
FftmPlan FftPlanGuru64DftR2C(int rank, const FFTIodim64 *dims, int howmanyRank, const FFTIodim64 *howmanyDims,
    double *in, void *out, unsigned flags);
FftmPlan FftPlanGuru64SplitDftR2C(int rank, const FFTIodim64 *dims, int howmanyRank, const FFTIodim64 *howmanyDims,
    double *in, double *ro, double *io, unsigned flags);
// C2R wrapper-plan interface
FftmPlan FftPlanDftC2R3D(int n0, int n1, int n2, void *in, double *out, unsigned flags);
FftmPlan FftPlanGuruDftC2R(int rank, const void *dims, int howmanyRank, const void *howmanyDims, void *in,
    double *out, unsigned flags);
FftmPlan FftPlanGuruSplitDftC2R(int rank, const void *dims, int howmanyRank, const void *howmanyDims,
    double *ri, double *ii, double *out, unsigned flags);
FftmPlan FftPlanGuru64DftC2R(int rank, const FFTIodim64 *dims, int howmanyRank, const FFTIodim64 *howmanyDims,
    void *in, double *out, unsigned flags);
FftmPlan FftPlanGuru64SplitDftC2R(int rank, const FFTIodim64 *dims, int howmanyRank, const FFTIodim64 *howmanyDims,
    double *ri, double *ii, double *out, unsigned flags);
// R2R wrapper-plan interface
FftmPlan FftPlanR2R(int rank, const int *n, double *in, double *out, const FFTR2RKind *kind, unsigned flags);
FftmPlan FftPlanR2R1D(int n, double *in, double *out, FFTR2RKind kind, unsigned flags);
FftmPlan FftPlanR2R2D(int n0, int n1, double *in, double *out, FFTR2RKind kind0, FFTR2RKind kind1, unsigned flags);
FftmPlan FftPlanR2R3D(int n0, int n1, int n2, double *in, double *out, FFTR2RKind kind0, FFTR2RKind kind1,
    FFTR2RKind kind2, unsigned flags);
FftmPlan FftPlanGuruR2R(int rank, const void *dims, int howmanyRank, const void *howmanyDims, double *in,
    double *out, const FFTR2RKind *kind, unsigned flags);
FftmPlan FftPlanGuru64R2R(int rank, const FFTIodim64 *dims, int howmanyRank, const FFTIodim64 *howmanyDims, double *in,
    double *out, const void *kind, unsigned flags);
FftmPlan FftPlanManyR2R(int rank, const int *n, int howmany, double *in, const int *inembed, int istride, int idist,
    double *out, const int *onembed, int ostride, int odist, const void *kind, unsigned flags);
#ifdef __cplusplus
}
#endif
#endif