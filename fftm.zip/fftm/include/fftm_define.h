/*
 * Copyright (c) Huawei Technologies Co., Ltd. 2023-2023. All rights reserved.
 */

#ifndef FFTM_DEFINE_H
#define FFTM_DEFINE_H

typedef enum {
    FFTM_RET_SUCCESS = 0,
    FFTM_RET_FAIL = -1,
    FFTM_RET_UNSOLVABLE = -2,
    FFTM_RET_UNSUPPORT = -3,
    FFTM_RET_NULL_PTR = -4,
    FFTM_RET_PARAM_INVALID = -5,
    FFTM_RET_MEMALLOC_FAIL = -6,
    FFTM_RET_FALLBACK_TO_BASELIB = -7
} FFTErrno;

// keep same with FFTW, but no effect
typedef enum {
    FFTM_MEASURE = 0,
    FFTM_DESTROY_INPUT = (1U << 0),
    FFTM_UNALIGNED = (1U << 1),
    FFTM_CONSERVE_MEMORY = (1U << 2),
    FFTM_EXHAUSTIVE = (1U << 3),
    FFTM_PRESERVE_INPUT = (1U << 4),
    FFTM_PATIENT = (1U << 5),
    FFTM_ESTIMATE = (1U << 6),
    FFTM_WISDOM_ONLY = (1U << 21)
} FFTFlags;

typedef enum {
    FFTM_FORWARD = -1,
    FFTM_BACKWARD = 1
} FFTSign;

typedef enum {
    FFTM_N_RANK_1 = 1,
    FFTM_N_RANK_2 = 2,
    FFTM_N_RANK_3 = 3
} FFTNRanks;

typedef enum {
    FFT_COMPUTE_TYPE_C2C = 0,
    FFT_COMPUTE_TYPE_R2C = 1,
    FFT_COMPUTE_TYPE_C2R = 2,
} FFTComputeType;

typedef enum {
    FFT_COMPUTE_FLAG_FULL_LEN = 0,
    FFT_COMPUTE_FLAG_HALF_LEN = 1,
    FFT_COMPUTE_FLAG_BLUESTEIN = 1 << 1,
    FFT_COMPUTE_FLAG_FALLBACK_BASELIB = 1 << 31
} FFTComputeFlag;

#endif