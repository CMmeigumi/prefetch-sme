module FFTM

  use iso_c_binding

  integer(C_INT), parameter :: FFT_COMPUTE_TYPE_C2C = 0
  integer(C_INT), parameter :: FFT_COMPUTE_TYPE_C2R = 1
  integer(C_INT), parameter :: FFT_COMPUTE_TYPE_R2C = 2
  integer(C_INT), parameter :: FFTM_FORWARD = -1
  integer(C_INT), parameter :: FFTM_BACKWARD = 1

  interface
    type(C_PTR) function FftPlanDft(rank, n, in, out, sign, flags) bind(C, name='FftPlanDft')
      import
      integer(C_INT), value :: rank
      integer(C_INT), dimension(*), intent(in) :: n
      complex(C_DOUBLE_COMPLEX), dimension(*), intent(in) :: in
      complex(C_DOUBLE_COMPLEX), dimension(*), intent(out) :: out
      integer(C_INT), value :: sign
      integer(C_INT), value :: flags
    end function FftPlanDft
    
    type(C_PTR) function FftPlanDft1D(n, in, out, sign, flags) bind(C, name='FftPlanDft1D')
      import
      integer(C_INT), value :: n
      complex(C_DOUBLE_COMPLEX), dimension(*), intent(in) :: in
      complex(C_DOUBLE_COMPLEX), dimension(*), intent(out) :: out
      integer(C_INT), value :: sign
      integer(C_INT), value :: flags
    end function FftPlanDft1D
    
    type(C_PTR) function FftPlanDft2D(n0, n1, in, out, sign, flags) bind(C, name='FftPlanDft2D')
      import
      integer(C_INT), value :: n0
      integer(C_INT), value :: n1
      complex(C_DOUBLE_COMPLEX), dimension(*), intent(in) :: in
      complex(C_DOUBLE_COMPLEX), dimension(*), intent(out) :: out
      integer(C_INT), value :: sign
      integer(C_INT), value :: flags
    end function FftPlanDft2D

    type(C_PTR) function FftPlanDft3D(n0, n1, n2, in, out, sign, flags) bind(C, name='FftPlanDft3D')
    import
      integer(C_INT), value :: n0
      integer(C_INT), value :: n1
      integer(C_INT), value :: n2
      complex(C_DOUBLE_COMPLEX), dimension(*), intent(out) :: in
      complex(C_DOUBLE_COMPLEX), dimension(*), intent(out) :: out
      integer(C_INT), value :: sign
      integer(C_INT), value :: flags
    end function FftPlanDft3D

    type(C_PTR) function FftPlanManyDft(rank, n, howmany, in, inembed, istride, idist, out, onembed, ostride, odist, sign, flags) &
      bind(C, name='FftPlanManyDft')
      import
      integer(C_INT), value :: rank
      integer(C_INT), dimension(*), intent(in) :: n
      integer(C_INT), value :: howmany
      complex(C_DOUBLE_COMPLEX), dimension(*), intent(in) :: in
      integer(C_INT), dimension(*), intent(in) :: inembed
      integer(C_INT), value :: istride
      integer(C_INT), value :: idist
      complex(C_DOUBLE_COMPLEX), dimension(*), intent(out) :: out
      integer(C_INT), dimension(*), intent(in) :: onembed
      integer(C_INT), value :: ostride
      integer(C_INT), value :: odist
      integer(C_INT), value :: sign
      integer(C_INT), value :: flags
    end function FftPlanManyDft

    type(C_PTR) function FftPlanDftR2C(rank, n, in, out, flags) bind(C, name='FftPlanDftR2C')
      import
      integer(C_INT), value :: rank
      integer(C_INT), dimension(*), intent(in) :: n
      real(C_DOUBLE), dimension(*), intent(in) :: in
      complex(C_DOUBLE_COMPLEX), dimension(*), intent(out) :: out
      integer(C_INT), value :: flags
    end function FftPlanDftR2C
    
    type(C_PTR) function FftPlanDftR2C1D(n, in, out, flags) bind(C, name='FftPlanDftR2C1D')
      import
      integer(C_INT), value :: n
      real(C_DOUBLE), dimension(*), intent(in) :: in
      complex(C_DOUBLE_COMPLEX), dimension(*), intent(out) :: out
      integer(C_INT), value :: flags
    end function FftPlanDftR2C1D
    
    type(C_PTR) function FftPlanDftR2C2D(n0, n1, in, out, flags) bind(C, name='FftPlanDftR2C2D')
      import
      integer(C_INT), value :: n0
      integer(C_INT), value :: n1
      real(C_DOUBLE), dimension(*), intent(in) :: in
      complex(C_DOUBLE_COMPLEX), dimension(*), intent(out) :: out
      integer(C_INT), value :: flags
    end function FftPlanDftR2C2D

    type(C_PTR) function FftPlanManyDftR2C(rank, n, howmany, in, inembed, istride, idist, out, onembed, ostride, odist, flags) &
      bind(C, name='FftPlanManyDftR2C')
      import
      integer(C_INT), value :: rank
      integer(C_INT), dimension(*), intent(in) :: n
      integer(C_INT), value :: howmany
      real(C_DOUBLE), dimension(*), intent(in) :: in
      integer(C_INT), dimension(*), intent(in) :: inembed
      integer(C_INT), value :: istride
      integer(C_INT), value :: idist
      complex(C_DOUBLE_COMPLEX), dimension(*), intent(out) :: out
      integer(C_INT), dimension(*), intent(in) :: onembed
      integer(C_INT), value :: ostride
      integer(C_INT), value :: odist
      integer(C_INT), value :: flags
    end function FftPlanManyDftR2C
    
    type(C_PTR) function FftPlanDftC2R(rank,n,in,out,flags) bind(C, name='FftPlanDftC2R')
      import
      integer(C_INT), value :: rank
      integer(C_INT), dimension(*), intent(in) :: n
      complex(C_DOUBLE_COMPLEX), dimension(*), intent(in) :: in
      real(C_DOUBLE), dimension(*), intent(out) :: out
      integer(C_INT), value :: flags
    end function FftPlanDftC2R
    
    type(C_PTR) function FftPlanDftC2R1D(n,in,out,flags) bind(C, name='FftPlanDftC2R1D')
      import
      integer(C_INT), value :: n
      complex(C_DOUBLE_COMPLEX), dimension(*), intent(in) :: in
      real(C_DOUBLE), dimension(*), intent(out) :: out
      integer(C_INT), value :: flags
    end function FftPlanDftC2R1D
    
    type(C_PTR) function FftPlanDftC2R2D(n0,n1,in,out,flags) bind(C, name='FftPlanDftC2R2D')
      import
      integer(C_INT), value :: n0
      integer(C_INT), value :: n1
      complex(C_DOUBLE_COMPLEX), dimension(*), intent(in) :: in
      real(C_DOUBLE), dimension(*), intent(out) :: out
      integer(C_INT), value :: flags
    end function FftPlanDftC2R2D

    type(C_PTR) function FftPlanManyDftC2R(rank, n, howmany, in, inembed, istride, idist, out, onembed, ostride, odist, flags) &
                         bind(C, name='FftPlanManyDftC2R')
      import
      integer(C_INT), value :: rank
      integer(C_INT), dimension(*), intent(in) :: n
      integer(C_INT), value :: howmany
      complex(C_DOUBLE_COMPLEX), dimension(*), intent(in) :: in
      integer(C_INT), dimension(*), intent(in) :: inembed
      integer(C_INT), value :: istride
      integer(C_INT), value :: idist
      real(C_DOUBLE), dimension(*), intent(out) :: out
      integer(C_INT), dimension(*), intent(in) :: onembed
      integer(C_INT), value :: ostride
      integer(C_INT), value :: odist
      integer(C_INT), value :: flags
    end function FftPlanManyDftC2R

    subroutine FftExecute(p) bind(C, name='FftExecute')
      import
      type(C_PTR), value :: p
    end subroutine FftExecute

    subroutine FftExecuteDftR2C(p, in, out) bind(C, name='FftExecuteDftR2C')
      import
      type(C_PTR), value :: p
      real(C_DOUBLE), dimension(*), intent(in) :: in
      complex(C_DOUBLE_COMPLEX), dimension(*), intent(out) :: out
    end subroutine FftExecuteDftR2C
    
    subroutine FftExecuteDftC2R(p, in, out) bind(C, name='FftExecuteDftC2R')
      import
      type(C_PTR), value :: p
      complex(C_DOUBLE_COMPLEX), dimension(*), intent(in) :: in
      real(C_DOUBLE), dimension(*), intent(out) :: out
    end subroutine FftExecuteDftC2R

    subroutine FftExecuteDft(p, in, out) bind(C, name='FftExecuteDft')
      import
      type(C_PTR), value :: p
      complex(C_DOUBLE_COMPLEX), dimension(*), intent(in) :: in
      complex(C_DOUBLE_COMPLEX), dimension(*), intent(out) :: out
    end subroutine FftExecuteDft

    subroutine FftDestroy(p) bind(C, name='FftDestroy')
      import
      type(C_PTR), value :: p
    end subroutine FftDestroy

    type(C_PTR) function FftAlignPtr(ptr, n) bind(C, name='FftAlignPtr')
      import
      type(C_PTR), value :: ptr
      integer(C_INT), value :: n
    end function FftAlignPtr

    type(C_PTR) function FftAlignedAlloc(size) bind(C, name='FftAlignedAlloc')
      import
      integer(C_INT), value :: size
    end function FftAlignedAlloc

    subroutine FftAlignedFree(ptr) bind(C, name='FftAlignedFree')
      import
      type(C_PTR), value :: ptr
    end subroutine FftAlignedFree

    type(C_PTR) function FftGetVersion() bind(C, name='FftGetVersion')
    end function FftGetVersion

    type(C_PTR) function FftPlanDftR2CF77(rank, n, in, out, flags) bind(C, name='FftPlanDftR2C')
      import
      integer(C_INT), value :: rank
      integer(C_INT), dimension(*), intent(in) :: n
      complex(C_DOUBLE_COMPLEX), dimension(*), intent(in) :: in
      complex(C_DOUBLE_COMPLEX), dimension(*), intent(out) :: out
      integer(C_INT), value :: flags
    end function FftPlanDftR2CF77
    
    type(C_PTR) function FftPlanDftR2C1DF77(n, in, out, flags) bind(C, name='FftPlanDftR2C1D')
      import
      integer(C_INT), value :: n
      complex(C_DOUBLE_COMPLEX), dimension(*), intent(in) :: in
      complex(C_DOUBLE_COMPLEX), dimension(*), intent(out) :: out
      integer(C_INT), value :: flags
    end function FftPlanDftR2C1DF77
    
    type(C_PTR) function FftPlanDftR2C2DF77(n0, n1, in, out, flags) bind(C, name='FftPlanDftR2C2D')
      import
      integer(C_INT), value :: n0
      integer(C_INT), value :: n1
      complex(C_DOUBLE_COMPLEX), dimension(*), intent(in) :: in
      complex(C_DOUBLE_COMPLEX), dimension(*), intent(out) :: out
      integer(C_INT), value :: flags
    end function FftPlanDftR2C2DF77

    type(C_PTR) function FftPlanDftR2C3DF77(n2, n1, n0, in, out, flags) bind(C, name='FftPlanDftR2C3D')
      import
      integer(C_INT), value :: n2
      integer(C_INT), value :: n1
      integer(C_INT), value :: n0
      complex(C_DOUBLE_COMPLEX), dimension(*), intent(in) :: in
      complex(C_DOUBLE_COMPLEX), dimension(*), intent(out) :: out
      integer(C_INT), value :: flags
    end function FftPlanDftR2C3DF77
    
    type(C_PTR) function FftPlanManyDftR2CF77(rank, n, howmany, in, inembed, istride, idist, out, onembed, ostride, odist, flags) &
      bind(C, name='FftPlanManyDftR2C')
      import
      integer(C_INT), value :: rank
      integer(C_INT), dimension(*), intent(in) :: n
      integer(C_INT), value :: howmany
      complex(C_DOUBLE_COMPLEX), dimension(*), intent(in) :: in
      integer(C_INT), dimension(*), intent(in) :: inembed
      integer(C_INT), value :: istride
      integer(C_INT), value :: idist
      complex(C_DOUBLE_COMPLEX), dimension(*), intent(out) :: out
      integer(C_INT), dimension(*), intent(in) :: onembed
      integer(C_INT), value :: ostride
      integer(C_INT), value :: odist
      integer(C_INT), value :: flags
    end function FftPlanManyDftR2CF77
    
    type(C_PTR) function FftPlanDftC2RF77(rank,n,in,out,flags) bind(C, name='FftPlanDftC2R')
      import
      integer(C_INT), value :: rank
      integer(C_INT), dimension(*), intent(in) :: n
      complex(C_DOUBLE_COMPLEX), dimension(*), intent(in) :: in
      complex(C_DOUBLE_COMPLEX), dimension(*), intent(out) :: out
      integer(C_INT), value :: flags
    end function FftPlanDftC2RF77
    
    type(C_PTR) function FftPlanDftC2R1DF77(n,in,out,flags) bind(C, name='FftPlanDftC2R1D')
      import
      integer(C_INT), value :: n
      complex(C_DOUBLE_COMPLEX), dimension(*), intent(in) :: in
      complex(C_DOUBLE_COMPLEX), dimension(*), intent(out) :: out
      integer(C_INT), value :: flags
    end function FftPlanDftC2R1DF77
    
    type(C_PTR) function FftPlanDftC2R2DF77(n0,n1,in,out,flags) bind(C, name='FftPlanDftC2R2D')
      import
      integer(C_INT), value :: n0
      integer(C_INT), value :: n1
      complex(C_DOUBLE_COMPLEX), dimension(*), intent(in) :: in
      complex(C_DOUBLE_COMPLEX), dimension(*), intent(out) :: out
      integer(C_INT), value :: flags
    end function FftPlanDftC2R2DF77

    type(C_PTR) function FftPlanDftC2R3DF77(n2,n1,n0,in,out,flags) bind(C, name='FftPlanDftC2R3D')
      import
      integer(C_INT), value :: n2
      integer(C_INT), value :: n1
      integer(C_INT), value :: n0
      complex(C_DOUBLE_COMPLEX), dimension(*), intent(in) :: in
      complex(C_DOUBLE_COMPLEX), dimension(*), intent(out) :: out
      integer(C_INT), value :: flags
    end function FftPlanDftC2R3DF77
      
    type(C_PTR) function FftPlanManyDftC2RF77(rank, n, howmany, in, inembed, istride, idist, out, onembed, ostride, odist, flags) &
                        bind(C, name='FftPlanManyDftC2R')
      import
      integer(C_INT), value :: rank
      integer(C_INT), dimension(*), intent(in) :: n
      integer(C_INT), value :: howmany
      complex(C_DOUBLE_COMPLEX), dimension(*), intent(in) :: in
      integer(C_INT), dimension(*), intent(in) :: inembed
      integer(C_INT), value :: istride
      integer(C_INT), value :: idist
      complex(C_DOUBLE_COMPLEX), dimension(*), intent(out) :: out
      integer(C_INT), dimension(*), intent(in) :: onembed
      integer(C_INT), value :: ostride
      integer(C_INT), value :: odist
      integer(C_INT), value :: flags
    end function FftPlanManyDftC2RF77

    subroutine FftExecuteDftR2CF77(p, in, out) bind(C, name='FftExecuteDftR2C')
      import
      type(C_PTR), value :: p
      complex(C_DOUBLE_COMPLEX), dimension(*), intent(in) :: in
      complex(C_DOUBLE_COMPLEX), dimension(*), intent(out) :: out
    end subroutine FftExecuteDftR2CF77
    
    subroutine FftExecuteDftC2RF77(p, in, out) bind(C, name='FftExecuteDftC2R')
      import
      type(C_PTR), value :: p
      complex(C_DOUBLE_COMPLEX), dimension(*), intent(in) :: in
      complex(C_DOUBLE_COMPLEX), dimension(*), intent(out) :: out
    end subroutine FftExecuteDftC2RF77
end interface
  
contains
  
  subroutine DFftPlanDft(p, rank, n, in, out, sign, flags)
      type(C_PTR), intent(out) :: p
      integer, intent(in) :: rank
      integer, dimension(:), intent(in) :: n
      complex(C_DOUBLE_COMPLEX), dimension(*), intent(inout) :: in
      complex(C_DOUBLE_COMPLEX), dimension(*), intent(inout) :: out
      integer, intent(in) :: sign
      integer, intent(in) :: flags
      integer, dimension(size(n)) :: n_rev
      n_rev(1:size(n):1) = n(1:size(n):-1)
      p = FftPlanDft(rank, n, in, out, sign, flags)
    end subroutine DFftPlanDft
    
    subroutine DFftPlanDft1D(p, n, in, out, sign, flags)
      type(C_PTR), intent(out) :: p
      integer(C_INT), intent(in) :: n
      complex(C_DOUBLE_COMPLEX), dimension(*), intent(inout) :: in
      complex(C_DOUBLE_COMPLEX), dimension(*), intent(inout) :: out
      integer(C_INT), value :: sign
      integer(C_INT), value :: flags
      p = FftPlanDft1D(n, in, out, sign, flags)
    end subroutine DFftPlanDft1D
    
    subroutine DFftPlanDft2D(p, n0, n1, in, out, sign, flags)
      type(C_PTR), intent(out) :: p
      integer(C_INT), value :: n0
      integer(C_INT), value :: n1
      complex(C_DOUBLE_COMPLEX), dimension(*), intent(inout) :: in
      complex(C_DOUBLE_COMPLEX), dimension(*), intent(inout) :: out
      integer(C_INT), value :: sign
      integer(C_INT), value :: flags
      p = FftPlanDft2D(n1, n0, in, out, sign, flags)
    end subroutine DFftPlanDft2D

    subroutine DFftPlanDft3D(p, n0, n1, n2, in, out, sign, flags)
	  type(C_PTR), intent(out) :: p
      integer(C_INT), value :: n0
      integer(C_INT), value :: n1
      integer(C_INT), value :: n2
      complex(C_DOUBLE_COMPLEX), dimension(*), intent(inout) :: in
      complex(C_DOUBLE_COMPLEX), dimension(*), intent(inout) :: out
      integer(C_INT), value :: sign
      integer(C_INT), value :: flags
      p = FftPlanDft3D(n2, n1, n0, in, out, sign, flags)
    end subroutine DFftPlanDft3D

    subroutine DFftPlanManyDft(p, rank, n, howmany, in, inembed, istride, idist, out, onembed, ostride, odist, sign, flags)
      type(C_PTR), intent(out) :: p
      integer(C_INT), value :: rank
      integer(C_INT), dimension(:), intent(in) :: n
      integer(C_INT), value :: howmany
      complex(C_DOUBLE_COMPLEX), dimension(*), intent(inout) :: in
      integer(C_INT), dimension(:), intent(in) :: inembed
      integer(C_INT), value :: istride
      integer(C_INT), value :: idist
      complex(C_DOUBLE_COMPLEX), dimension(*), intent(inout) :: out
      integer(C_INT), dimension(:), intent(in) :: onembed
      integer(C_INT), value :: ostride
      integer(C_INT), value :: odist
      integer(C_INT), value :: sign
      integer(C_INT), value :: flags
      integer, dimension(size(n)) :: n_rev
      integer, dimension(size(inembed)) :: inembed_rev
      integer, dimension(size(onembed)) :: onembed_rev
      n_rev(1:size(n):1) = n(1:size(n):-1)
      inembed_rev(1:size(inembed):1) = inembed(1:size(inembed):-1)
      onembed_rev(1:size(onembed):1) = onembed(1:size(onembed):-1)
      p = FftPlanManyDft(rank, n_rev, howmany, in, inembed_rev, istride, idist, out, onembed_rev, ostride, odist, sign, flags)
    end subroutine DFftPlanManyDft

    subroutine DFftPlanDftR2C(p, rank, n, in, out, flags)
      type(C_PTR), intent(out) :: p
      integer(C_INT), value :: rank
      integer(C_INT), dimension(:), intent(in) :: n
      complex(C_DOUBLE_COMPLEX), dimension(*), intent(inout) :: in
      complex(C_DOUBLE_COMPLEX), dimension(*), intent(inout) :: out
      integer(C_INT), value :: flags
      integer, dimension(size(n)) :: n_rev
      n_rev(1:size(n):1) = n(1:size(n):-1)
      p = FftPlanDftR2CF77(rank, n_rev, in, out, flags)
    end subroutine DFftPlanDftR2C
    
    subroutine DFftPlanDftR2C1D(p, n, in, out, flags)
      type(C_PTR), intent(out) :: p
      integer(C_INT), value :: n
      complex(C_DOUBLE_COMPLEX), dimension(*), intent(inout) :: in
      complex(C_DOUBLE_COMPLEX), dimension(*), intent(inout) :: out
      integer(C_INT), value :: flags
      p = FftPlanDftR2C1DF77(n, in, out, flags)
    end subroutine DFftPlanDftR2C1D
    
    subroutine DFftPlanDftR2C2D(p, n0, n1, in, out, flags)
      type(C_PTR), intent(inout) :: p
      integer(C_INT), value :: n0
      integer(C_INT), value :: n1
      complex(C_DOUBLE_COMPLEX), dimension(*), intent(inout) :: in
      complex(C_DOUBLE_COMPLEX), dimension(*), intent(inout) :: out
      integer(C_INT), value :: flags
      p = FftPlanDftR2C2DF77(n1, n0, in, out, flags)
    end subroutine DFftPlanDftR2C2D
    
    subroutine DFftPlanManyDftR2C(p, rank, n, howmany, in, inembed, istride, idist, out, onembed, ostride, odist, flags)
      type(C_PTR), intent(out) :: p
      integer(C_INT), value :: rank
      integer(C_INT), dimension(:), intent(in) :: n
      integer(C_INT), value :: howmany
      complex(C_DOUBLE_COMPLEX), dimension(*), intent(inout) :: in
      integer(C_INT), dimension(:), intent(in) :: inembed
      integer(C_INT), value :: istride
      integer(C_INT), value :: idist
      complex(C_DOUBLE_COMPLEX), dimension(*), intent(inout) :: out
      integer(C_INT), dimension(:), intent(in) :: onembed
      integer(C_INT), value :: ostride
      integer(C_INT), value :: odist
      integer(C_INT), value :: flags
      integer, dimension(size(n)) :: n_rev
      integer, dimension(size(inembed)) :: inembed_rev
      integer, dimension(size(onembed)) :: onembed_rev
      n_rev(1:size(n):1) = n(1:size(n):-1)
      inembed_rev(1:size(inembed):1) = inembed(1:size(inembed):-1)
      onembed_rev(1:size(onembed):1) = onembed(1:size(onembed):-1)
      p = FftPlanManyDftR2CF77(rank, n_rev, howmany, in, inembed_rev, istride, idist, out, onembed_rev, ostride, odist, flags)
    end subroutine DFftPlanManyDftR2C
    
    subroutine DFftPlanDftC2R(p, rank, n, in, out, flags)
      type(C_PTR), intent(out) :: p
      integer(C_INT), value :: rank
      integer(C_INT), dimension(*), intent(in) :: n
      complex(C_DOUBLE_COMPLEX), dimension(*), intent(inout) :: in
      complex(C_DOUBLE_COMPLEX), dimension(*), intent(inout) :: out
      integer(C_INT), value :: flags
      p = FftPlanDftC2RF77(rank,n,in,out,flags)
    end subroutine DFftPlanDftC2R
    
    subroutine DFftPlanDftC2R1D(p, n, in, out, flags)
      type(C_PTR), intent(out) :: p
      integer(C_INT), value :: n
      complex(C_DOUBLE_COMPLEX), dimension(*), intent(inout) :: in
      complex(C_DOUBLE_COMPLEX), dimension(*), intent(inout) :: out
      integer(C_INT), value :: flags
      p = FftPlanDftC2R1DF77(n,in,out,flags)
    end subroutine DFftPlanDftC2R1D
    
    subroutine DFftPlanDftC2R2D(p, n0, n1, in, out, flags)
      type(C_PTR), intent(out) :: p
      integer(C_INT), value :: n0
      integer(C_INT), value :: n1
      complex(C_DOUBLE_COMPLEX), dimension(*), intent(inout)  :: in
      complex(C_DOUBLE_COMPLEX), dimension(*), intent(inout) :: out
      integer(C_INT), value :: flags
      p = FftPlanDftC2R2DF77(n1, n0, in, out, flags)
    end subroutine DFftPlanDftC2R2D
      
    subroutine DFftPlanManyDftC2R(p, rank, n, howmany, in, inembed, istride, idist, out, onembed, ostride, odist, flags)
      type(C_PTR), intent(out) :: p
      integer(C_INT), value :: rank
      integer(C_INT), dimension(:), intent(in) :: n
      integer(C_INT), value :: howmany
      complex(C_DOUBLE_COMPLEX), dimension(*), intent(inout) :: in
      integer(C_INT), dimension(:), intent(in) :: inembed
      integer(C_INT), value :: istride
      integer(C_INT), value :: idist
      complex(C_DOUBLE_COMPLEX), dimension(*), intent(inout) :: out
      integer(C_INT), dimension(:), intent(in) :: onembed
      integer(C_INT), value :: ostride
      integer(C_INT), value :: odist
      integer(C_INT), value :: flags
      integer, dimension(size(n)) :: n_rev
      integer, dimension(size(inembed)) :: inembed_rev
      integer, dimension(size(onembed)) :: onembed_rev
      n_rev(1:size(n):1) = n(1:size(n):-1)
      inembed_rev(1:size(inembed):1) = inembed(1:size(inembed):-1)
      onembed_rev(1:size(onembed):1) = onembed(1:size(onembed):-1)
      p = FftPlanManyDftC2RF77(rank, n_rev, howmany, in, inembed_rev, istride, idist, out, onembed_rev, ostride, odist, flags)
    end subroutine DFftPlanManyDftC2R

    subroutine DFftPlanDftR2C3D(p, n0, n1, n2, in, out, flags)
      type(C_PTR), intent(inout) :: p
      integer(C_INT), value :: n0
      integer(C_INT), value :: n1
      integer(C_INT), value :: n2
      complex(C_DOUBLE_COMPLEX), dimension(*), intent(in) :: in
      complex(C_DOUBLE_COMPLEX), dimension(*), intent(out) :: out
      integer(C_INT), value, intent(in) :: flags
      p = FftPlanDftR2C3DF77(n2, n1, n0, in, out, flags)
    end subroutine DFftPlanDftR2C3D

    subroutine DFftPlanDftC2R3D(p, n0, n1, n2,in, out, flags)
      type(C_PTR), intent(inout) :: p
      integer(C_INT), value :: n0
      integer(C_INT), value :: n1
      integer(C_INT), value :: n2
      complex(C_DOUBLE_COMPLEX), dimension(*), intent(in)  :: in
      complex(C_DOUBLE_COMPLEX), dimension(*), intent(out) :: out
      integer(C_INT), value, intent(in) :: flags
      p = FftPlanDftC2R3DF77(n2, n1, n0, in, out, flags)
    end subroutine DFftPlanDftC2R3D
end module